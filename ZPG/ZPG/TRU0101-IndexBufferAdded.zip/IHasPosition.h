#pragma once
#include <glm/vec3.hpp> // glm::vec3
class IHasPosition
{
public:
	IHasPosition() {};
	glm::vec3 position;
};

