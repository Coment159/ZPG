#pragma once
#include <glm/vec3.hpp> // glm::vec3
class IHasFront {
public:
	IHasFront() {};
	glm::vec3 front;
};