#pragma once
#include "model.h"
class ModelT : public Model
{
public:
	ModelT
};

