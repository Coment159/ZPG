#pragma once
const float triangleSize = 3;
const float triangle[]{
     -.5f, .5f, .5f,  1,1,1,
       .5f, .5f, .5f,  1,1,1,
       .5f, -.5f, .5f, 1,1,1
};